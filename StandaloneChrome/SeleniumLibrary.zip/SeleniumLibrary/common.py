# -*- coding:utf-8 -*-
__author__ = "孙文翠"
import jsonpath,requests,json
import pymysql,random,datetime
# import pyperclip as pc
# import pyautogui
# import time
# import pywinauto
# from pywinauto.keyboard import send_keys   #导入send_keys库，实现模拟键盘操作

# l=LoginTest
class RequestApi():
    def token(self, basicUrl, **kwargs):
        url = basicUrl + kwargs['url']
        headers = kwargs['headers']
        data = kwargs['data']
        r = requests.post(url=url, headers=headers, data=json.dumps(data))
        r = r.json()
        access_token = jsonpath.jsonpath(r, '$.data.access_token')
        token_type = jsonpath.jsonpath(r, '$.data.token_type')
        # print(access_token,type(access_token))
        a = '{} {}'.format(token_type[0], access_token[0])
        returns = {'HSYL-AUTH': a}
        # print(returns)
        return returns


    def menuID(self, **kwargs):
        r = requests.get(url=kwargs['menuIdUrl'], headers=kwargs['headers'])
        r = r.json()
        return r


    def returnGet(self, basicUrl, **kwargs):
        url = basicUrl + kwargs['url']
        headers = kwargs['headers']
        r = requests.get(url=url, headers=headers)
        r = r.json()
        return r
    def getResponse(self ,menuName ,apiPart ,jpath,menuId_index='0',filePath='../testDataRecord/testData.txt'):  # 举例：self.getResponse('销售订单','/trade-po/order/queryPage','$.data.records[0].billNo')
        basicUrl ='http://trade-saas-dev.c9d1c973fa315470eb49b82764004d642.cn-hangzhou.alicontainer.com/prod-api'
        basicHeaders ={'Content-Type' :'application/json'}
        tokenData ={'url' :'/trade-auth/token',
                   'data' :{"account": "sysadmin" ,"password": "6adff3f7009f9d256406e1a5ff6249fa",
                           "grantType": "password" ,"tenantId": "000000" ,"tenantCode": "888888"
                              ,"password2": "BYg1FjDPyLJXdEfjU/HYrg=="},
                   'headers' :{'Authorization' :'Basic c3dvcmQ6c3dvcmRfc2VjcmV0' ,'Content-Type' :'application/json'} ,}
        # 登录
        a1 =self.token(basicUrl ,**tokenData)
        headerNomal =dict(basicHeaders, **a1)
        # 获取用户的菜单路由信息
        routeData ={'url' :'/trade-sm/menu/routes' ,'headers' :headerNomal }
        a2 =self.returnGet(basicUrl ,**routeData)
        menuMenuId =jsonpath.jsonpath(a2 ,'$.data[12].children[4].children[0].id')
        # 获取菜单ID
        menuData = {'url': '/trade-sm/menu/queryAll?name={}&menuId={}'.format(menuName ,menuMenuId), 'headers': headerNomal}
        a3 = self.returnGet(basicUrl ,**menuData)
        testMenuId = jsonpath.jsonpath(a3, '$.data[{}].id'.format(menuId_index))
        ##获取单据号
        orderData ={'url' :'{}pageNo=1&pageSize=1&menuId={}'.format(apiPart ,testMenuId) ,'headers' :headerNomal}
        response =self.returnGet(basicUrl ,**orderData)
        orderNo =jsonpath.jsonpath(response ,jpath)[0]
        # orderNo=jsonpath.jsonpath(response,'$.data.records[0].billNo')[0]

        print(orderNo)
        with open(filePath,'a',encoding='utf-8') as f:
            text1 = '{date}-{menuName}:{orderNo}\n'.format(date=l.day(self, 0), menuName=menuName, orderNo=orderNo)
            text2='数据详情：{}\n'.format(jsonpath.jsonpath(response ,'$.data.records[0]')[0])

            f.write(text1+text2+'###============================================================================\n')#向文件写入一个序列字符串列表，如果需要换行需要自己加入换行符
        return orderNo
class mysqlDo():
    id='swc' + str(random.randint(1000000, 9999999))
    def day(self,d):
        day = (datetime.datetime.now() + datetime.timedelta(days=d)).strftime('%Y-%m-%d')
        return day
    def mysqlDo_update(self, sql):
        # 1.建立mysql连接
        conn = pymysql.connect(host='8.134.73.69', port=3306, user='fabrictest', passwd='fabrictest', database='saas_dcas',
                               charset='utf8')
        # 2.建立游标
        cur = conn.cursor()
        # 3.执行脚本
        cur.execute(sql)
        cur.execute('commit')
        conn.close()

    def mysqlDo_select(self,sql):
        # 1.建立mysql连接
        conn = pymysql.connect(host='8.134.73.69', port=3306, user='fabrictest', passwd='fabrictest', database='saas_dcas',
                               charset='utf8')
        # 2.建立游标
        cur = conn.cursor()
        # 3.执行脚本
        cur.execute(sql)
        result = cur.fetchone()[0]
        conn.close()
        return result
# class keyOp():
#     def paste(self,path):
#         # 使用pywinauto来选择文件
#         app = pywinauto.Desktop()
#         # 选择文件上传的窗口
#         dlg = app["打开"]
#
#         # 选择文件地址输入框，点击激活
#         dlg["Toolbar3"].click()
#         # 键盘输入上传文件的路径
#         send_keys(path)
#         # 键盘输入回车，打开该路径
#         send_keys("{VK_RETURN}")
#
#         # # 选中文件名输入框，输入文件名
#         # dlg["文件名(&N):Edit"].type_keys("97K鲜花.jpeg")
#         # # 点击打开
#         # dlg["打开(&O)"].click()


if __name__ == "__main__":
    suite = RequestApi()
    suite.getResponse('销售订单', '/trade-po/order/queryPage?', '$.data.records[0].billNo',menuId_index='0')

    # ##预置数据
    # s = mysqlDo()
    # id='swc'+str(random.randint(1000000,9999999))
    # sql1='''INSERT INTO `saas_dcas`.`dcas_report_production` (`id`, `org_id`, `org_code`, `org_name`,
    # `tenant_id`, `product`, `statistical_type`, `report_date`, `report_unit`, `report_value`, `business_code`, `create_by`,
    # `create_time`, `create_by_id`, `create_by_full_name`, `update_by`, `update_time`, `update_by_id`, `update_by_full_name`)
    # VALUES ('{id}', '20b48a5456c14a92a30034284a693c57', '10.01.01', 'GEW', 'bcd9f32267e7d2b66e50010b0fa85fbd', '{name}',
    #  '日产量', '{day} 00:00:00', 'T', 15108.20, '{no}', 'gew1', '2022-11-21 23:24:43', 'd475aa2c2262e6b02bb8389175ba55c6', 'GEW厂1', NULL, NULL, NULL,
    #  NULL)'''.format(id=id,day=s.day(0),name='SWC细纱',no='SWC001')
    # s.mysqlDo_update(sql1)
    # ###查询
    # sql2 = '''SELECT id FROM `saas_dcas`.`dcas_report_production` WHERE `product` LIKE '%SWC细纱%' LIMIT 0,1000'''
    # a = s.mysqlDo_select(sql2)
    # print(a)
    # ##清理数据
    # sql3 = '''delete from `saas_dcas`.`dcas_report_production` WHERE id="{id}"'''.format(id=id)
    # s.mysqlDo_update(sql3)
    # keyOp.paste('E:/img/flower.png')
