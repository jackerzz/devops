import os
import base64
import time
import requests
from robot.utils import get_link_path
from selenium.webdriver import ActionChains
from SeleniumLibrary.base import LibraryComponent, keyword
from SeleniumLibrary.utils.cv_utils import Scroll
from SeleniumLibrary.utils.cv_utils import loop_find, loop_find_pro
from robot.libraries.BuiltIn import BuiltIn  # type: ignore
class PyautoguiLib(LibraryComponent):
    def login_token(self,body,url):
        response = requests.post(
            url=url,
            json=body, headers={"Content-Type": "application/json"})
        assert response.status_code ==200
        BuiltIn().set_suite_variable('${access_token}', response.json()["data"]["access_token"])


    def menu_id(self,url,token):

        response = requests.post(url=url
                         ,headers={'Content-Type':'application/json;charset=UTF-8',"HSYL-AUTH":"Bearer " + token})
        assert response.status_code == 200
        assert response.json()["data"][3]['children'][0]['children'][1]['id']
        BuiltIn().set_suite_variable('${menuid}',response.json()["data"][3]['children'][0]['children'][1]['id'])


    def toBse64(self,filepath):
        with open(filepath, 'rb') as f1:
            base64_str = base64.b64encode(f1.read())
            str = base64_str.decode('utf-8')  # str
            return str

    def _embed_to_log_as_base64(self, tag_path,reult_path, width):
        self.info(
            '</td></tr><tr><td colspan="3">'
            '<img alt="screenshot" class="tag_path" '
            f'src="data:image/png;base64,{self.toBse64(tag_path)}" width="100px">'
            f'<img alt="screenshot" class="reult_path" '
            f'src="data:image/png;base64,{self.toBse64(reult_path)}" width="{width}px">',
            html=True,
        )

    def _embed_to_log_as_file(self,tag_path,reult_path, width):
        tag_src = "../"+tag_path
        reult_src = get_link_path(reult_path, self.log_dir).replace('result/', '')
        self.info(
            '</td></tr><tr><td colspan="3">'
            f'<a href="{tag_src}"><img src="{tag_src}" "></a>'
            f'<a href="{reult_src}"><img src="{reult_src}" width="{width}px"></a>',
            html=True,
        )